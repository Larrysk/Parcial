package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.service.autofill.UserData;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import android.widget.Toast;

public class UserActivity extends AppCompatActivity {

    private TextView nameTextView;

    private TextView cantTextView;
    private TextView IDTextView;
    private TextView PrecioTextView;
    private Button insertButton;
    private EditText nameEditText;
    private EditText PrecioEditText;
    private EditText cantEditText;
    private EditText IDEditText;
    private EditText

    private static final int DEFAULT_AGE = 18;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        nameTextView = findViewById(R.id.nameTextView);
        PrecioTextView = findViewById(R.id.PrecioTextView);
        cantTextView = findViewById(R.id.cantTextView);
        IDTextView = findViewById(R.id.IDTextView);
        insertButton = findViewById(R.id.insertButton);
        nameEditText = findViewById(R.id.nameEditText);
        cantEditText = findViewById(R.id.cantEditText);
        IDEditText = findViewById(R.id.IDEditText);

        databaseHelper = new DatabaseHelper(this);

        String name = "John Doe";
        int age = calculateAge(DEFAULT_AGE, 5);
        String location = "New York";

        nameTextView.setText(name);
        ageTextView.setText(String.valueOf(age));
        locationTextView.setText(location);

        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String location = locationEditText.getText().toString();
                int age = calculateAge(DEFAULT_AGE, 5);

                UserData userData = new UserData(name, age, location);
                boolean isInserted = databaseHelper.insertUserData(userData);

                if (isInserted) {
                    Toast.makeText(UserActivity.this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UserActivity.this, "Failed to insert data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private int calculateAge(int baseAge, int exponent) {
        if (exponent == 0) {
            return baseAge;
        } else {
            return baseAge * calculateAge(baseAge, exponent - 1);
        }
    }
}
